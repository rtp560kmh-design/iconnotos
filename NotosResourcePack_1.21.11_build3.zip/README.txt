Original File by the team behind Hoplite
Emissive Textures, Secret weapons and icons made by vred_